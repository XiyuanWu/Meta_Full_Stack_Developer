from django.contrib import admin
# from .models import Menu
# from .models import Employee
# from .models import Booking
# from .models import Drink
# from .models import DrinkCategory

# Register your models here.



# P10
# admin.site.register(Menu)

# P7
# admin.site.register(Employee)

#P6
# admin.site.register(Booking)

# P4-5
# admin.site.register(Drink)
# admin.site.register(DrinkCategory)
