# from django import forms
# from .models import Booking



# P6
# class BookingForm(forms.ModelForm):
#     class Meta:
#         model = Booking
#         fields = "__all__"