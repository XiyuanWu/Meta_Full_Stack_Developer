from django.db import models

# Create your models here.
# P10
class Menu(models.Model):
    name = models.CharField(max_length=200)
    price = models.IntegerField()

    def __str__(self):
        return self.name





# P6
# class Booking(models.Model):
#     first_name = models.CharField(max_length=200)
#     last_name = models.CharField(max_length=200)
#     guest_count = models.IntegerField()
#     reservation_date = models.DateField(auto_now=True)
#     comments = models.CharField(max_length=1000)


# P4-5
# class Drink(models.Model):
#     drink_name = models.CharField(max_length=200)
#     price = models.IntegerField()
#     category_id = models.ForeignKey("DrinkCategory", on_delete=models.PROTECT, default=None)
    
# class DrinkCategory(models.Model):
#     category_name = models.CharField(max_length=200)
