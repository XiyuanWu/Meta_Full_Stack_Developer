from django.urls import path
from . import views

urlpatterns = [
    # P11
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('menu/', views.menu, name='menu'),
    path('book/', views.book, name='book'),
]

# P10
# path("menu/", views.menu, name="menu"),

# P9
# path("about/", views.about, name="about"),

#P6
# path('booking/', views.form_view),


# P3
# path('', views.home, name='home'),
# path('about/', views.about, name='about'),
# path('menu/', views.menu, name='menu'),
# path('book/', views.book, name='book'),
