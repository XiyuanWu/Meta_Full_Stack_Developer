from django.shortcuts import render
# from app.forms import BookingForm
# from django.http import HttpResponse
# from .models import Menu

# Create your views here.
# P11
def home(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def menu(request):
    return render(request, 'menu.html')

def book(request):
    return render(request, 'book.html')




# P10
# def menu(request):
#     menu_items = Menu.objects.all()
#     return render(request, "menu.html", {"menu": menu_items})


# P9
# def about(request):
#     about_content = {'about': "Little Lemon is a family-owned Mediterranean restaurant, \
#                      focused on traditional recipes served with a modern twist. The chefs \
#                      draw inspiration from Italian, Greek, and Turkish culture and have a \
#                      menu of 12–15 items that they rotate seasonally. The restaurant has a \
#                      rustic and relaxed atmosphere with moderate prices, making it a popular \
#                      place for a meal any time of the day."} 
#     return render(request, "about.html", {'content': about_content})

# def menu(request):
#     about_content = {'about': "Little Lemon is a family-owned Mediterranean restaurant, \
#                      focused on traditional recipes served with a modern twist. The chefs \
#                      draw inspiration from Italian, Greek, and Turkish culture and have a \
#                      menu of 12–15 items that they rotate seasonally. The restaurant has a \
#                      rustic and relaxed atmosphere with moderate prices, making it a popular \
#                      place for a meal any time of the day."} 
#     return render(request, "menu.html", {'content': about_content})


# P6
# def form_view(request):
#     form = BookingForm()
#     if request.method == 'POST':
#         form = BookingForm(request.POST)
#         if form.is_valid():
#             form.save()
#     context = {"form" : form}
#     return render(request, "booking.html", context)


# P3
# def home(request):
#     return HttpResponse("Welcome to Little Lemon!")

# def about(request):
#     return HttpResponse("About us")

# def menu(request):
#     return HttpResponse("Menu")

# def book(request):
#     return HttpResponse("Book a table")
