Project structure:

```
Final_Project_9/        # <-- main folder (manage.py will live here)
├─ littlelemon/         # inner project package (settings/urls/asgi/wsgi)
└─ restaurant/          # app

```


Some userful tips:

run server
```
python manage.py runserver
```

migration (run if changes on models)
```
python manage.py makemigrations
python manage.py migrate
```

create superuser
```
python manage.py createsuperuser