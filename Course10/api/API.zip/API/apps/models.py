from django.db import models
from django.contrib.auth.models import User

# Create your models here.

# P5
class Rating(models.Model):
    menuitem_id = models.SmallIntegerField()
    rating = models.SmallIntegerField(default=0)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    


# P4
# class Category(models.Model):
#     slug = models.SlugField()
#     title = models.CharField(max_length=255)
    
#     def __str__(self):
#         return self.title
    
# class MenuItem(models.Model):
#     title = models.CharField(max_length=255)
#     price = models.DecimalField(max_digits=6, decimal_places=2)
#     inventory = models.SmallIntegerField()
#     category = models.ForeignKey(Category, on_delete=models.PROTECT, default=1)
    
#     def __str__(self):
#         return self.title


# P3
# class MenuItem(models.Model):
#     title = models.CharField(max_length=255)
#     price = models.DecimalField(max_digits=6, decimal_places=2)
#     inventory = models.SmallIntegerField()

# P2
# class Book(models.Model):
#     title = models.CharField(max_length=255)
#     author = models.CharField(max_length=255)
#     price = models.DecimalField(max_digits=6, decimal_places=2)

#     def __str__(self):
#         return self.title



# P1
# class Book(models.Model):
#     title = models.CharField(max_length=255)
#     author = models.CharField(max_length=255)
#     price = models.DecimalField(max_digits=6, decimal_places=2)

#     def __str__(self):
#         return self.title
    
#     class Meta:
#         indexes = [models.Index(fields=['price'])]