from django.urls import path
from . import views


urlpatterns = [
    
    # P5
    path('ratings', views.RatingsView.as_view()),
    
    # P4
    # path('categories', views.CategoriesView.as_view()),
    # path('menu-items', views.MenuItemsView.as_view()),
    
    # P3
    # path('menu-items', views.MenuItemsView.as_view()),
    # path('menu-items/<int:pk>', views.SingleMenuItemView.as_view()),

    # P2
    # path('books', views.BookView.as_view()),
    # path('books/<int:pk>', views.SingleBookView.as_view()),

    # P1
    # path('books', views.books, name='books'),
]