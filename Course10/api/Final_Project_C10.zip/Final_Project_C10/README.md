# Cheatsheet

Final Project #10

run server
```
python manage.py runserver
```

migration (run if changes on models)
```
python manage.py makemigrations
python manage.py migrate
```

create superuser
```
python manage.py createsuperuser
```