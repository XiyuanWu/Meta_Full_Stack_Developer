from rest_framework import permissions


class IsManager(permissions.BasePermission):
    """Allow only users in the 'Manager' group."""
    def has_permission(self, request, view):
        return (
            request.user
            and request.user.is_authenticated
            and request.user.groups.filter(name="Manager").exists()
        )


class IsDeliveryCrew(permissions.BasePermission):
    """Allow only users in the 'Delivery crew' group."""
    def has_permission(self, request, view):
        return (
            request.user
            and request.user.is_authenticated
            and request.user.groups.filter(name="Delivery crew").exists()
        )


class IsCustomer(permissions.BasePermission):
    """Users not assigned to any group (default = customers)."""
    def has_permission(self, request, view):
        return (
            request.user
            and request.user.is_authenticated
            and not request.user.groups.exists()
        )
